BAR_CHART = "bar-chart"

NATION_DROPDOWN = "nation-dropdown"
SELECT_ALL_NATIONS_BUTTON = "select-all-nations-button"
