BAR_CHART = "bar-chart"
PIE_CHART = "pie-chart"

SELECT_ALL_CATEGORIES_BUTTON = "select-all-categories-button"
CATEGORY_DROPDOWN = "category-dropdown"

SELECT_ALL_MONTHS_BUTTON = "select-all-months-button"
MONTH_DROPDOWN = "month-dropdown"

YEAR_DROPDOWN = "year-dropdown"
SELECT_ALL_YEARS_BUTTON = "select-all-years-button"
